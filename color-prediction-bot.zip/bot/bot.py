
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters
from bot.config import BOT_TOKEN
from bot.handlers import start, submit_uid, submit_photo, predict
from bot.admin import approve

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("approve", approve))
app.add_handler(MessageHandler(filters.PHOTO, submit_photo))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, submit_uid))
app.add_handler(MessageHandler(filters.TEXT, predict))
app.run_polling()
