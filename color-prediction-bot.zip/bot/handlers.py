
from telegram import Update
from telegram.ext import ContextTypes
from bot.config import ADMIN_ID

users = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    users.setdefault(user_id, {"uid": None, "approved": False})
    await update.message.reply_text(
        "Welcome!\nRegister → Send UID → Send Screenshot\nAdmin will approve after ₹200+ deposit."
    )

async def submit_uid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    users[update.effective_user.id]["uid"] = update.message.text
    await update.message.reply_text("UID received. Now send screenshot.")

async def submit_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await context.bot.send_message(
        ADMIN_ID,
        f"New User\nTG ID: {update.effective_user.id}\nUID: {users[update.effective_user.id]['uid']}"
    )
    await context.bot.send_photo(ADMIN_ID, update.message.photo[-1].file_id)
    await update.message.reply_text("Sent to admin. Wait for approval.")

async def predict(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not users.get(update.effective_user.id, {}).get("approved"):
        await update.message.reply_text("Not approved yet.")
        return
    await update.message.reply_text("Prediction:\nColour: RED\nNumber: 7\nBig/Small: BIG")
