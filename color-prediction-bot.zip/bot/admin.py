
from telegram import Update
from telegram.ext import ContextTypes
from bot.handlers import users
from bot.config import ADMIN_ID

async def approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    uid = int(context.args[0])
    users[uid]["approved"] = True
    await update.message.reply_text(f"Approved {uid}")
