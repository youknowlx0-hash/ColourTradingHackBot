
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

BOT_TOKEN = "8288208743:AAH-0lOckoLl70g79DoYIyO9odwlvGmcZPA"
ADMIN_ID = 681380610

users = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Welcome\n\n"
        "1️⃣ UID bhejo (text)\n"
        "2️⃣ Screenshot bhejo (image)\n"
        "ℹ️ ₹200+ deposit ke baad admin approval"
    )

async def uid_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.startswith('/'):
        return
    users[update.effective_user.id] = {"uid": update.message.text, "approved": False}
    await update.message.reply_text("✅ UID saved. Screenshot bhejo.")

async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in users:
        await update.message.reply_text("❌ Pehle UID bhejo.")
        return
    await context.bot.send_message(
        ADMIN_ID,
        f"🆕 Approval Request\nTelegram ID: {uid}\nUID: {users[uid]['uid']}\n/approve {uid}"
    )
    await context.bot.send_photo(ADMIN_ID, update.message.photo[-1].file_id)
    await update.message.reply_text("📨 Admin ko bhej diya.")

async def approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    try:
        uid = int(context.args[0])
        users[uid]["approved"] = True
        await context.bot.send_message(uid, "✅ Approved! /predict use karo.")
        await update.message.reply_text("Approved.")
    except:
        await update.message.reply_text("Use: /approve USER_ID")

async def predict(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in users or not users[uid]["approved"]:
        await update.message.reply_text("❌ Approval pending.")
        return
    await update.message.reply_text(
        "📊 Prediction\n🎨 RED\n🔢 7\n⚖️ BIG"
    )

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("approve", approve))
    app.add_handler(CommandHandler("predict", predict))
    app.add_handler(MessageHandler(filters.PHOTO, photo_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, uid_handler))
    print("Bot running...")
    app.run_polling()

if __name__ == "__main__":
    main()
