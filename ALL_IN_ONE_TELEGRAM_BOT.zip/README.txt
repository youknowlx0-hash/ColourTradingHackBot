ALL IN ONE TELEGRAM BOT

Steps:
1. Install Python 3.10+
2. Open folder
3. Run: bash run.sh
