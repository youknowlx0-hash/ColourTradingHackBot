
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

BOT_TOKEN = "8288208743:AAH-0lOckoLl70g79DoYIyO9odwlvGmcZPA"
ADMIN_ID = 681380610

users = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Welcome\n\n"
        "1️⃣ Apni UID bhejo (text)\n"
        "2️⃣ Screenshot bhejo (image)\n\n"
        "ℹ️ ₹200+ deposit ke baad admin approval dega"
    )

async def receive_uid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text.startswith("/"):
        return
    users[update.effective_user.id] = {
        "uid": update.message.text,
        "approved": False
    }
    await update.message.reply_text("✅ UID mil gayi. Ab screenshot bhejo.")

async def receive_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in users:
        await update.message.reply_text("❌ Pehle UID bhejo.")
        return

    await context.bot.send_message(
        ADMIN_ID,
        f"🆕 Approval Request\nTelegram ID: {user_id}\nUID: {users[user_id]['uid']}\n\n/approve {user_id}"
    )
    await context.bot.send_photo(ADMIN_ID, update.message.photo[-1].file_id)

    await update.message.reply_text("📨 Details admin ko bhej di. Approval ka wait karo.")

async def approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    try:
        uid = int(context.args[0])
        users[uid]["approved"] = True
        await context.bot.send_message(uid, "✅ Approved! Ab /predict use karo.")
        await update.message.reply_text("✅ User approved.")
    except:
        await update.message.reply_text("Use: /approve USER_ID")

async def predict(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in users or not users[user_id]["approved"]:
        await update.message.reply_text("❌ Abhi approval nahi mila.")
        return

    await update.message.reply_text(
        "📊 Prediction\n"
        "🎨 Colour: RED\n"
        "🔢 Number: 7\n"
        "⚖️ BIG"
    )

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("approve", approve))
    app.add_handler(CommandHandler("predict", predict))
    app.add_handler(MessageHandler(filters.PHOTO, receive_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, receive_uid))
    print("Bot running...")
    app.run_polling()

if __name__ == "__main__":
    main()
